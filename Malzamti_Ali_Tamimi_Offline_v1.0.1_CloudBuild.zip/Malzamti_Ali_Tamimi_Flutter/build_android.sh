#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="${ROOT}/.android_build"
OUT_DIR="${ROOT}/build-output"

if ! command -v flutter >/dev/null 2>&1; then
  echo "ERROR: Flutter SDK is not installed or flutter is not on PATH." >&2
  echo "Install Flutter and Android tooling first: https://docs.flutter.dev/install" >&2
  exit 2
fi

rm -rf "$BUILD_DIR"
mkdir -p "$OUT_DIR"

flutter create \
  --platforms=android \
  --org com.ali.altamimi \
  --project-name malzamti \
  "$BUILD_DIR"

cp -a "$ROOT/lib" "$BUILD_DIR/"
cp -a "$ROOT/assets" "$BUILD_DIR/"
cp "$ROOT/pubspec.yaml" "$BUILD_DIR/"
cp "$ROOT/analysis_options.yaml" "$BUILD_DIR/" 2>/dev/null || true

cd "$BUILD_DIR"
flutter pub get
flutter analyze
flutter build apk --release

APK="$BUILD_DIR/build/app/outputs/flutter-apk/app-release.apk"
if [[ ! -f "$APK" ]]; then
  echo "ERROR: APK was not created at expected path: $APK" >&2
  exit 3
fi

cp "$APK" "$OUT_DIR/Malzamti-Ali-Tamimi-v1.0.0.apk"
echo "SUCCESS: $OUT_DIR/Malzamti-Ali-Tamimi-v1.0.0.apk"
