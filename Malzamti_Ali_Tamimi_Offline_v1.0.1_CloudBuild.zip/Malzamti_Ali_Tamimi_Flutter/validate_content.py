#!/usr/bin/env python3
"""Structural (not scientific) validation for Malzamti offline content."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent
content_path = root / 'assets' / 'data' / 'content.json'
data = json.loads(content_path.read_text(encoding='utf-8'))
errors = []
counts = {key: 0 for key in ('subjects', 'chapters', 'topicNotes', 'questions', 'terms', 'formulas', 'examples')}

for grade, grade_info in data.get('grades', {}).items():
    listed = grade_info.get('subjects', [])
    content_subjects = data.get('subjectContent', {}).get(grade, {})
    if set(listed) != set(content_subjects):
        errors.append(f'{grade}: subject list and content keys differ')
    counts['subjects'] += len(listed)
    for subject in listed:
        for index, chapter in enumerate(content_subjects.get(subject, {}).get('chapters', []), 1):
            counts['chapters'] += 1
            if not chapter.get('title'):
                errors.append(f'{grade}/{subject}/chapter {index}: missing title')
            for field in ('questions', 'terms', 'formulas', 'examples', 'topicNotes'):
                entries = chapter.get(field, [])
                counts[field] += len(entries)
                for entry_index, pair in enumerate(entries, 1):
                    if not isinstance(pair, list) or len(pair) < 2 or not all(str(x).strip() for x in pair[:2]):
                        errors.append(f'{grade}/{subject}/{chapter.get("title")}/{field}/{entry_index}: invalid pair')
            if not chapter.get('revisionPlan'):
                errors.append(f'{grade}/{subject}/{chapter.get("title")}: missing revision plan')

report = {
    'version': '1.0.0',
    'validation_type': 'structural_only_not_scientific_review',
    'errors': errors,
    'counts': counts,
    'valid': not errors,
}
(root / 'CONTENT_AUDIT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
raise SystemExit(1 if errors else 0)
