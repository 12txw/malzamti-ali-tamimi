
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const MalzamtiApp());

class MalzamtiApp extends StatefulWidget {
  const MalzamtiApp({super.key});
  @override
  State<MalzamtiApp> createState() => _MalzamtiAppState();
}

class _MalzamtiAppState extends State<MalzamtiApp> {
  bool dark = true;
  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFF2C66D);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ملزمتي - علي التميمي',
      theme: ThemeData(
        useMaterial3: true,
        brightness: dark ? Brightness.dark : Brightness.light,
        colorScheme: ColorScheme.fromSeed(
          seedColor: gold,
          brightness: dark ? Brightness.dark : Brightness.light,
          surface: dark ? const Color(0xFF111D35) : const Color(0xFFF7F4EC),
        ),
        scaffoldBackgroundColor: dark ? const Color(0xFF091225) : const Color(0xFFF4F6FA),
        appBarTheme: const AppBarTheme(centerTitle: false, backgroundColor: Colors.transparent),
        cardTheme: CardThemeData(
          color: dark ? const Color(0xFF14213B) : Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: dark ? const Color(0xFF2A3D60) : const Color(0xFFE1E6EF))),
        ),
      ),
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: HomeScreen(dark: dark, onTheme: () => setState(() => dark = !dark)),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  final bool dark;
  final VoidCallback onTheme;
  const HomeScreen({super.key, required this.dark, required this.onTheme});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, dynamic> data = {};
  bool loading = true;
  int tab = 0;
  final TextEditingController search = TextEditingController();
  Set<String> favorites = {};
  String query = '';

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final raw = await rootBundle.loadString('assets/data/content.json');
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      data = jsonDecode(raw) as Map<String, dynamic>;
      favorites = prefs.getStringList('favorites')?.toSet() ?? {};
      loading = false;
    });
  }
  Future<void> _toggleFavorite(String key) async {
    setState(() { favorites.contains(key) ? favorites.remove(key) : favorites.add(key); });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('favorites', favorites.toList());
  }
  Map<String, dynamic> get grades => Map<String, dynamic>.from(data['grades'] ?? {});
  Map<String, dynamic> get allContent => Map<String, dynamic>.from(data['subjectContent'] ?? {});

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(
        title: const Text('ملزمتي - علي التميمي', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(onPressed: widget.onTheme, icon: Icon(widget.dark ? Icons.light_mode : Icons.dark_mode)), const SizedBox(width: 8)],
      ),
      body: IndexedStack(index: tab, children: [
        _home(),
        _searchPage(),
        _favoritesPage(),
        _aboutPage(),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.search), label: 'بحث'),
          NavigationDestination(icon: Icon(Icons.bookmark_outline), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.info_outline), label: 'عن التطبيق'),
        ],
      ),
    );
  }

  Widget _home() {
    final names = grades.keys.toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(colors: [Color(0xFF263D65), Color(0xFF14213B)]),
          border: Border.all(color: const Color(0xFF40577F)),
        ),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('أهلاً بك في ملزمتي 👋', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Text('ملخصات وشرح وأسئلة للخامس والسادس العلمي، بمكان واحد وبدون إنترنت.', style: TextStyle(height: 1.8, color: Color(0xFFD6E0F1))),
        ]),
      ),
      const SizedBox(height: 22),
      const Text('اختر صفك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      ...names.map((grade) => _gradeCard(grade)),
      const SizedBox(height: 16),
      const Text('المحتوى المضاف حالياً', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text('المكتبة تضم ${allContent.values.whereType<Map>().fold<int>(0, (sum, value) => sum + value.length)} مواد لها ملفات محتوى، وبداخلها فصول وملخصات ومراجعات. المحتوى يتوسع ويُدقّق تباعاً مقابل طبعات الكتب العراقية.', style: const TextStyle(height: 1.8)),
    ]);
  }

  Widget _gradeCard(String grade) {
    final subjects = List<String>.from((grades[grade] as Map)['subjects'] ?? []);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: const CircleAvatar(backgroundColor: Color(0xFFF2C66D), foregroundColor: Color(0xFF19243A), child: Icon(Icons.school)),
        title: Text(grade, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${subjects.length} مواد دراسية'),
        trailing: const Icon(Icons.arrow_back_ios_new, size: 16),
        onTap: () => _openGrade(grade),
      ),
    );
  }

  void _openGrade(String grade) {
    final subjects = List<String>.from((grades[grade] as Map)['subjects'] ?? []);
    Navigator.push(context, MaterialPageRoute(builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(grade)),
        body: ListView(padding: const EdgeInsets.all(16), children: subjects.map((subject) {
          return Card(child: ListTile(
            leading: const Icon(Icons.menu_book, color: Color(0xFFF2C66D)),
            title: Text(subject, style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Text(_hasContent(grade, subject)
              ? '${((allContent[grade] as Map)[subject] as Map)['chapters']?.length ?? 0} فصول متاحة'
              : 'المحتوى التفصيلي قيد الإعداد'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => _openSubject(grade, subject),
          ));
        }).toList()),
      ),
    )));
  }

  bool _hasContent(String grade, String subject) =>
      (allContent[grade] is Map) && ((allContent[grade] as Map)[subject] is Map);

  void _openSubject(String grade, String subject) {
    final gradeMap = allContent[grade] is Map ? Map<String,dynamic>.from(allContent[grade]) : {};
    final subjectData = gradeMap[subject] is Map ? Map<String,dynamic>.from(gradeMap[subject]) : {};
    final chapters = List<Map<String,dynamic>>.from((subjectData['chapters'] ?? []).map((e) => Map<String,dynamic>.from(e)));
    Navigator.push(context, MaterialPageRoute(builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(subject)),
        body: chapters.isEmpty
          ? _emptySubject(subject, grade)
          : ListView(padding: const EdgeInsets.all(16), children: [
              Text(grade, style: TextStyle(color: Theme.of(context).colorScheme.secondary)),
              const SizedBox(height: 10),
              Text(subjectData['sourceNote']?.toString() ?? 'محتوى المادة', style: const TextStyle(height: 1.7)),
              const SizedBox(height: 14),
              ...chapters.asMap().entries.map((entry) => Card(child: ListTile(
                leading: CircleAvatar(child: Text('${entry.key+1}')),
                title: Text(entry.value['title'].toString()),
                subtitle: Text('${(entry.value['topics'] as List).length} موضوعات'),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => _openChapter(grade, subject, entry.value),
              ))),
            ]),
      ),
    )));
  }

  Widget _emptySubject(String subject, String grade) => ListView(padding: const EdgeInsets.all(18), children: [
    Text(grade, style: const TextStyle(fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(subject, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('تم إنشاء صفحة المادة وأقسامها. لم ندرج ملخصات أو فصولاً غير متحقق منها حتى لا يحصل الطالب على معلومات غير مطابقة للكتاب.', style: TextStyle(height: 1.8)),
      const SizedBox(height: 12),
      const Text('الأقسام: ملخص • قوانين • أمثلة محلولة • أسئلة وزارية • أسئلة تدريبية • اختبار', style: TextStyle(height: 1.8)),
    ]))),
  ]);

  void _openChapter(String grade, String subject, Map<String,dynamic> chapter) {
    final title = chapter['title'].toString();
    final key = '$grade|$subject|$title';
    Navigator.push(context, MaterialPageRoute(builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(title), actions: [
          IconButton(onPressed: () => _toggleFavorite(key), icon: Icon(favorites.contains(key) ? Icons.bookmark : Icons.bookmark_border)),
        ]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          _sectionCard('الملخص', chapter['summary']?.toString() ?? 'لا يوجد ملخص بعد', Icons.summarize),
          _sectionCard('موضوعات الفصل', (chapter['topics'] as List).map((e) => '• $e').join('\n'), Icons.list_alt),
          if ((chapter['topicNotes'] as List? ?? []).isNotEmpty)
            _pairsCard('شرح الموضوعات', List<List<dynamic>>.from((chapter['topicNotes'] ?? []).map((e) => List<dynamic>.from(e)))),
          if ((chapter['revisionPlan'] as List? ?? []).isNotEmpty)
            _sectionCard('خطة مراجعة الفصل', (chapter['revisionPlan'] as List).map((e) => '• $e').join('\n'), Icons.checklist),
          if ((chapter['formulas'] as List? ?? []).isNotEmpty)
            _pairsCard('القوانين والعلاقات', List<List<dynamic>>.from((chapter['formulas'] ?? []).map((e) => List<dynamic>.from(e)))),
          if ((chapter['examples'] as List? ?? []).isNotEmpty)
            _pairsCard('أمثلة وطريقة الحل', List<List<dynamic>>.from((chapter['examples'] ?? []).map((e) => List<dynamic>.from(e)))),
          _pairsCard('التعاريف والمصطلحات', List<List<dynamic>>.from((chapter['terms'] ?? []).map((e) => List<dynamic>.from(e)))),
          _pairsCard('أسئلة المراجعة والأجوبة', List<List<dynamic>>.from((chapter['questions'] ?? []).map((e) => List<dynamic>.from(e)))),
          const SizedBox(height: 12),
          if ((chapter['questions'] as List? ?? []).isNotEmpty)
            FilledButton.icon(
              onPressed: () => _openReviewQuiz(title, List<List<dynamic>>.from((chapter['questions'] ?? []).map((e) => List<dynamic>.from(e)))),
              icon: const Icon(Icons.quiz_outlined),
              label: const Text('اختبر نفسك بهذا الفصل'),
            ),
          const SizedBox(height: 10),
          const Text('ملاحظة: أسئلة المراجعة تدريبية من إعداد التطبيق، وليست أسئلة وزارية منقولة.', style: TextStyle(color: Colors.grey)),
        ]),
      ),
    )));
  }

  void _openReviewQuiz(String title, List<List<dynamic>> questions) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: ReviewQuizPage(title: title, questions: questions),
    )));
  }

  Widget _sectionCard(String title, String body, IconData icon) => Card(
    child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Icon(icon, color: const Color(0xFFF2C66D)), const SizedBox(width: 8), Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold))]),
      const SizedBox(height: 10), Text(body, style: const TextStyle(height: 1.9)),
    ])),
  );

  Widget _pairsCard(String title, List<List<dynamic>> pairs) => Card(
    child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      ...pairs.map((pair) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(pair[0].toString(), style: const TextStyle(color: Color(0xFFF2C66D), fontWeight: FontWeight.bold)),
        const SizedBox(height: 4), Text(pair[1].toString(), style: const TextStyle(height: 1.8)),
        if (pair.length > 2) ...[
          const SizedBox(height: 4),
          Text(pair[2].toString(), style: const TextStyle(height: 1.7, color: Colors.grey)),
        ],
      ]))),
    ])),
  );

  Widget _searchPage() {
    final hits = <Map<String, String>>[];
    final q = query.trim().toLowerCase();
    if (q.isNotEmpty) {
      for (final grade in grades.keys) {
        final subjects = List<String>.from((grades[grade] as Map)['subjects'] ?? []);
        for (final subject in subjects) {
          if (('$grade $subject').toLowerCase().contains(q)) {
            hits.add({'grade': grade, 'subject': subject, 'detail': 'المادة'});
          }
          final gradeMap = allContent[grade] is Map ? Map<String,dynamic>.from(allContent[grade]) : {};
          final subjectData = gradeMap[subject] is Map ? Map<String,dynamic>.from(gradeMap[subject]) : {};
          final chapters = List<Map<String,dynamic>>.from((subjectData['chapters'] ?? []).map((e) => Map<String,dynamic>.from(e)));
          for (final chapter in chapters) {
            final title = chapter['title'].toString();
            if (('$grade $subject $title').toLowerCase().contains(q)) {
              hits.add({'grade': grade, 'subject': subject, 'detail': title, 'chapter': title});
            }
            final summary = chapter['summary']?.toString() ?? '';
            if (summary.toLowerCase().contains(q)) {
              hits.add({'grade': grade, 'subject': subject, 'detail': '$title • ملخص الفصل', 'chapter': title});
            }
            for (final topic in List<String>.from(chapter['topics'] ?? [])) {
              if (topic.toLowerCase().contains(q)) {
                hits.add({'grade': grade, 'subject': subject, 'detail': '$title • $topic', 'chapter': title});
              }
            }
            for (final note in List<List<dynamic>>.from((chapter['topicNotes'] ?? []).map((e) => List<dynamic>.from(e)))) {
              if (note.any((part) => part.toString().toLowerCase().contains(q))) {
                hits.add({'grade': grade, 'subject': subject, 'detail': '$title • شرح: ${note.first}', 'chapter': title});
              }
            }
            for (final step in List<String>.from(chapter['revisionPlan'] ?? [])) {
              if (step.toLowerCase().contains(q)) {
                hits.add({'grade': grade, 'subject': subject, 'detail': '$title • خطة المراجعة', 'chapter': title});
              }
            }
            for (final sectionName in ['terms', 'questions', 'formulas', 'examples', 'topicNotes']) {
              for (final pair in List<List<dynamic>>.from((chapter[sectionName] ?? []).map((e) => List<dynamic>.from(e)))) {
                final searchable = pair.map((e) => e.toString()).join(' ');
                if (searchable.toLowerCase().contains(q)) {
                  final label = sectionName == 'terms' ? 'مصطلح' : sectionName == 'questions' ? 'سؤال' : sectionName == 'formulas' ? 'قانون' : sectionName == 'topicNotes' ? 'شرح' : 'مثال';
                  hits.add({'grade': grade, 'subject': subject, 'detail': '$title • $label: ${pair.first}', 'chapter': title});
                }
              }
            }
          }
        }
      }
    }
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('البحث داخل التطبيق', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('البحث يعمل محلياً ولا يحتاج اتصالاً بالإنترنت.', style: TextStyle(color: Colors.grey)),
      const SizedBox(height: 12),
      TextField(
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'ابحث عن مادة أو فصل أو موضوع', border: OutlineInputBorder()),
        onChanged: (v) => setState(() => query = v),
      ),
      const SizedBox(height: 12),
      if (q.isNotEmpty && hits.isEmpty) const Text('ماكو نتائج مطابقة ضمن المحتوى الموجود على الجهاز.'),
      ...hits.map((hit) => Card(child: ListTile(
        title: Text(hit['detail']!),
        subtitle: Text('${hit['grade']} • ${hit['subject']}'),
        onTap: () {
          final chapterTitle = hit['chapter'];
          if (chapterTitle == null) {
            _openSubject(hit['grade']!, hit['subject']!);
          } else {
            _openChapterByTitle(hit['grade']!, hit['subject']!, chapterTitle);
          }
        },
      ))),
    ]);
  }

  void _openChapterByTitle(String grade, String subject, String title) {
    final gradeMap = allContent[grade] is Map ? Map<String, dynamic>.from(allContent[grade]) : {};
    final subjectData = gradeMap[subject] is Map ? Map<String, dynamic>.from(gradeMap[subject]) : {};
    final chapters = List<Map<String, dynamic>>.from(
      (subjectData['chapters'] ?? []).map((e) => Map<String, dynamic>.from(e)),
    );
    final matches = chapters.where((chapter) => chapter['title'].toString() == title);
    if (matches.isNotEmpty) _openChapter(grade, subject, matches.first);
  }

  void _openFavorite(String item) {
    final parts = item.split('|');
    if (parts.length < 3) return;
    final grade = parts[0], subject = parts[1], title = parts.sublist(2).join('|');
    final gradeMap = allContent[grade] is Map ? Map<String,dynamic>.from(allContent[grade]) : {};
    final subjectData = gradeMap[subject] is Map ? Map<String,dynamic>.from(gradeMap[subject]) : {};
    final chapters = List<Map<String,dynamic>>.from((subjectData['chapters'] ?? []).map((e) => Map<String,dynamic>.from(e)));
    final found = chapters.where((c) => c['title'].toString() == title).toList();
    if (found.isNotEmpty) _openChapter(grade, subject, found.first);
  }

  Widget _favoritesPage() {
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('الفصول المحفوظة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      if (favorites.isEmpty) const Text('ماكو فصول محفوظة بعد. افتح فصلاً واضغط علامة الحفظ.'),
      ...favorites.map((item) {
        final parts = item.split('|');
        return Card(child: ListTile(
          title: Text(parts.length > 2 ? parts[2] : item),
          subtitle: Text(parts.length > 1 ? '${parts[0]} • ${parts[1]}' : ''),
          trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _toggleFavorite(item)),
          onTap: () => _openFavorite(item),
        ));
      }),
    ]);
  }

  Widget _aboutPage() => const ListView(padding: EdgeInsets.all(18), children: [
    Text('ملزمتي - علي التميمي', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    SizedBox(height: 8),
    Text('تطبيق تعليمي عراقي للخامس والسادس العلمي.', style: TextStyle(height: 1.8)),
    SizedBox(height: 8),
    Text('المطور: Ali Al-Tamimi'),
    Text('الإصدار: 1.0.0 — نسخة تطويرية قبل البناء'),
    SizedBox(height: 12),
    Text('المحتوى يعمل من ملفات محلية داخل التطبيق. البحث والمفضلة لا يحتاجان إلى الإنترنت. هذه نسخة تطويرية وليست إصداراً نهائياً للنشر، ويجب تدقيق الشروح مع آخر طبعة وزارية.', style: TextStyle(height: 1.8)),
  ]);
}


class ReviewQuizPage extends StatefulWidget {
  final String title;
  final List<List<dynamic>> questions;
  const ReviewQuizPage({super.key, required this.title, required this.questions});
  @override
  State<ReviewQuizPage> createState() => _ReviewQuizPageState();
}

class _ReviewQuizPageState extends State<ReviewQuizPage> {
  int index = 0;
  bool reveal = false;
  @override
  Widget build(BuildContext context) {
    final item = widget.questions[index];
    return Scaffold(
      appBar: AppBar(title: const Text('اختبر نفسك')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Text(widget.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 8),
        LinearProgressIndicator(value: (index + 1) / widget.questions.length),
        const SizedBox(height: 8),
        Text('السؤال ${index + 1} من ${widget.questions.length}'),
        const SizedBox(height: 18),
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Text(item[0].toString(), style: const TextStyle(fontSize: 19, height: 1.8, fontWeight: FontWeight.w600)))),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: () => setState(() => reveal = !reveal),
          icon: Icon(reveal ? Icons.visibility_off : Icons.visibility),
          label: Text(reveal ? 'إخفاء الإجابة' : 'إظهار الإجابة'),
        ),
        if (reveal) Card(child: Padding(padding: const EdgeInsets.all(18), child: Text(item[1].toString(), style: const TextStyle(height: 1.9)))),
        const SizedBox(height: 18),
        Row(children: [
          Expanded(child: OutlinedButton(
            onPressed: index == 0 ? null : () => setState(() { index--; reveal = false; }),
            child: const Text('السابق'),
          )),
          const SizedBox(width: 10),
          Expanded(child: FilledButton(
            onPressed: index == widget.questions.length - 1 ? () => Navigator.pop(context) : () => setState(() { index++; reveal = false; }),
            child: Text(index == widget.questions.length - 1 ? 'إنهاء' : 'التالي'),
          )),
        ]),
      ]),
    );
  }
}
